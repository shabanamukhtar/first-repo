require('../modules/es6.regexp');
module.exports = require('../modules/$').core.RegExp;