require('../../modules/es6.object.statics-accept-primitives');
module.exports = require('../../modules/$').core.Object.isFrozen;