require('../../modules/core.object');
module.exports = require('../../modules/$').core.Object.classof;