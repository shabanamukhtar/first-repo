require('../../modules/es6.object.is');
module.exports = require('../../modules/$').core.Object.is;