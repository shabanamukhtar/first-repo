require('../../modules/es6.math');
module.exports = require('../../modules/$').core.Math.fround;