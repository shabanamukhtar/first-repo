require('../../modules/es7.string.rpad');
module.exports = require('../../modules/$').core.String.rpad;
