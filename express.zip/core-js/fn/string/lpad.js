require('../../modules/es7.string.lpad');
module.exports = require('../../modules/$').core.String.lpad;
