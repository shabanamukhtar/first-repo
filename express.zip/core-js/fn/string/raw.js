require('../../modules/es6.string.raw');
module.exports = require('../../modules/$').core.String.raw;