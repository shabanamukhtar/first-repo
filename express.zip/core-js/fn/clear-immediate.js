require('../modules/web.immediate');
module.exports = require('../modules/$').core.clearImmediate;