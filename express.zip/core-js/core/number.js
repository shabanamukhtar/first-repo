require('../modules/core.number.iterator');
require('../modules/core.number.math');
module.exports = require('../modules/$').core.Number;