require('../modules/core.array.turn');
module.exports = require('../modules/$').core.Array;