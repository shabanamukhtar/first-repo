require('../modules/es6.string.iterator');
require('../modules/web.dom.iterable');
require('../modules/core.$for');
module.exports = require('../modules/$').core.$for;
