require('../modules/es7.string.at');
require('../modules/es7.string.lpad');
require('../modules/es7.string.rpad');
module.exports = require('../modules/$').core.String;
